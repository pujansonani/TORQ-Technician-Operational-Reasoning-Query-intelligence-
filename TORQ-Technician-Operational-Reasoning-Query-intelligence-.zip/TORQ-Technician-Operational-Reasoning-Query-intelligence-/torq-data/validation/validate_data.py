#!/usr/bin/env python3
"""
TORQ Dataset Automated Validation Script
========================================
Checks referential integrity, mathematical consistency, schema compliance,
provenance declarations, and deliberate intelligence patterns across the TORQ synthetic dataset.

Outputs:
  - Prints PASS or FAIL to standard output
  - Generates validation/validation_report.md
"""

import os
import sys
import csv
import json
from datetime import datetime

# Base Directory Setup
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.dirname(SCRIPT_DIR)

# File Paths
DTC_PATH = os.path.join(DATA_DIR, 'dtc', 'dtc_kb.csv')
PARTS_PATH = os.path.join(DATA_DIR, 'parts', 'parts.json')
REPAIRS_PATH = os.path.join(DATA_DIR, 'repairs', 'repairs.csv')
CASE_001_PATH = os.path.join(DATA_DIR, 'demo', 'case_001.json')
REPORT_PATH = os.path.join(SCRIPT_DIR, 'validation_report.md')
PROCEDURES_DIR = os.path.join(DATA_DIR, 'procedures')

def run_validation():
    errors = []
    warnings = []
    stats = {}

    print("==================================================")
    print("      TORQ DATASET INTEGRITY VALIDATOR            ")
    print("==================================================")

    # 1. Validate JSON Files
    print("[1/8] Validating JSON files (parts.json & case_001.json)...")
    parts_data = []
    try:
        with open(PARTS_PATH, 'r', encoding='utf-8') as f:
            parts_data = json.load(f)
        stats['total_parts'] = len(parts_data)
    except Exception as e:
        errors.append(f"Malformed JSON in parts.json: {str(e)}")

    case_001_data = {}
    try:
        with open(CASE_001_PATH, 'r', encoding='utf-8') as f:
            case_001_data = json.load(f)
        stats['case_001_loaded'] = True
    except Exception as e:
        errors.append(f"Malformed JSON in case_001.json: {str(e)}")

    # 2. Check Part Duplicates & Schema
    print("[2/8] Validating Parts Catalog Schema & Unique IDs...")
    valid_part_ids = set()
    for idx, part in enumerate(parts_data):
        p_num = part.get('part_number')
        if not p_num:
            errors.append(f"parts.json item #{idx} missing 'part_number'")
            continue
        if p_num in valid_part_ids:
            errors.append(f"Duplicate part_number found in parts.json: '{p_num}'")
        valid_part_ids.add(p_num)

        if not part.get('data_status'):
            errors.append(f"Part '{p_num}' missing 'data_status'")

    # 3. Validate DTC Knowledge Base
    print("[3/8] Validating DTC Knowledge Base (dtc_kb.csv)...")
    valid_dtc_codes = set()
    dtc_rows = []
    if os.path.exists(DTC_PATH):
        try:
            with open(DTC_PATH, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    dtc_rows.append(row)
                    code = row.get('code')
                    if not code:
                        errors.append("dtc_kb.csv row missing 'code'")
                        continue
                    if code in valid_dtc_codes:
                        errors.append(f"Duplicate DTC code in dtc_kb.csv: '{code}'")
                    valid_dtc_codes.add(code)

                    # Check source_type & data_status
                    stype = row.get('source_type')
                    dstat = row.get('data_status')
                    if stype not in ['PUBLIC_STANDARD', 'SYNTHETIC_DEMO']:
                        errors.append(f"DTC '{code}' invalid source_type '{stype}'")
                    if dstat not in ['VERIFIED_PUBLIC', 'SYNTHETIC']:
                        errors.append(f"DTC '{code}' invalid data_status '{dstat}'")
        except Exception as e:
            errors.append(f"Error reading dtc_kb.csv: {str(e)}")
    else:
        errors.append(f"DTC file not found at {DTC_PATH}")
    stats['total_dtcs'] = len(valid_dtc_codes)

    # 4. Validate Procedures
    print("[4/8] Validating Procedure Markdown Decision Trees...")
    proc_files = [f for f in os.listdir(PROCEDURES_DIR) if f.endswith('.md')] if os.path.exists(PROCEDURES_DIR) else []
    stats['total_procedures'] = len(proc_files)
    if len(proc_files) < 6:
        errors.append(f"Expected at least 6 procedure files, found {len(proc_files)}")

    for pfile in proc_files:
        ppath = os.path.join(PROCEDURES_DIR, pfile)
        with open(ppath, 'r', encoding='utf-8') as f:
            content = f.read()
            if "SYNTHETIC DEMONSTRATION DATA" not in content:
                errors.append(f"Procedure '{pfile}' missing synthetic demonstration safety header")
            if "Document ID" not in content:
                errors.append(f"Procedure '{pfile}' missing Document ID header")

    # 5. Validate Repairs CSV (Referential Integrity, Costs, Patterns)
    print("[5/8] Validating Historical Repairs (repairs.csv)...")
    repair_case_ids = set()
    gap_cases_count = 0
    nova_q3q4_count = 0
    prove_evidence_count = 0
    repairs_rows = []

    if os.path.exists(REPAIRS_PATH):
        try:
            with open(REPAIRS_PATH, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row_idx, row in enumerate(reader, start=1):
                    repairs_rows.append(row)
                    cid = row.get('case_id')
                    if not cid:
                        errors.append(f"repairs.csv line {row_idx} missing 'case_id'")
                        continue
                    if cid in repair_case_ids:
                        errors.append(f"Duplicate case_id in repairs.csv: '{cid}'")
                    repair_case_ids.add(cid)

                    # Check DTC reference
                    dtc = row.get('dtc_code')
                    if dtc not in valid_dtc_codes:
                        errors.append(f"Case '{cid}' references unknown DTC '{dtc}'")

                    # Check Parts reference
                    parts_used_str = row.get('parts_used', '')
                    if parts_used_str:
                        for p_item in parts_used_str.split('|'):
                            p_item = p_item.strip()
                            if p_item and p_item not in valid_part_ids:
                                errors.append(f"Case '{cid}' references unknown Part '{p_item}'")

                    # Check Cost Calculation
                    try:
                        p_cost = float(row.get('parts_cost_inr', 0))
                        l_cost = float(row.get('labor_cost_inr', 0))
                        t_cost = float(row.get('total_cost_inr', 0))
                        if abs((p_cost + l_cost) - t_cost) > 0.01:
                            errors.append(f"Case '{cid}' invalid cost calculation: {p_cost} + {l_cost} != {t_cost}")
                    except ValueError:
                        errors.append(f"Case '{cid}' invalid cost numeric values")

                    # Check Provenance Status
                    if row.get('data_status') != 'SYNTHETIC_DEMO':
                        errors.append(f"Case '{cid}' data_status must be 'SYNTHETIC_DEMO'")

                    # Pattern Check 1: TORQ GAP
                    doc_path = row.get('documented_path', '').lower()
                    act_path = row.get('actual_path', '').lower()
                    root_cause = row.get('root_cause', '').lower()
                    if ('replace' in doc_path or 'sensor' in doc_path) and ('connector' in act_path or 'pin' in act_path or 'corrosion' in root_cause):
                        gap_cases_count += 1

                    # Pattern Check 2: TORQ PROVE Evidence
                    vev = row.get('verification_evidence', '')
                    if row.get('resolved', '').lower() == 'true':
                        if 'BEFORE:' in vev and 'AFTER:' in vev:
                            prove_evidence_count += 1
                        else:
                            errors.append(f"Case '{cid}' resolved without valid BEFORE/AFTER verification evidence")

                    # Pattern Check 3: TORQ NOVA Temporal Distribution
                    created_at = row.get('created_at', '')
                    vmodel = row.get('vehicle_model', '')
                    sw_ver = row.get('software_version', '')
                    if vmodel == 'TX-900' and sw_ver == 'v4.2.1' and ('connector' in root_cause or 'pin' in root_cause or 'corrosion' in root_cause):
                        if created_at >= '2025-07-01':
                            nova_q3q4_count += 1

        except Exception as e:
            errors.append(f"Error reading repairs.csv: {str(e)}")
    else:
        errors.append(f"Repairs file not found at {REPAIRS_PATH}")

    stats['total_repairs'] = len(repair_case_ids)
    stats['gap_cases'] = gap_cases_count
    stats['nova_q3q4_cases'] = nova_q3q4_count
    stats['prove_cases'] = prove_evidence_count

    # Check minimum required GAP cases
    if gap_cases_count < 8:
        errors.append(f"Expected at least 8 TORQ GAP deliberate cases, found {gap_cases_count}")

    # 6. Validate Case 001 Cross-References
    print("[6/8] Validating Main Demo Case (case_001.json)...")
    if case_001_data:
        c1_dtc = case_001_data.get('step_1_initial_state', {}).get('active_dtc', {}).get('code')
        if c1_dtc not in valid_dtc_codes:
            errors.append(f"case_001.json references unknown DTC '{c1_dtc}'")

        c1_parts = case_001_data.get('step_6_repair_execution', {}).get('parts_used', [])
        for cp in c1_parts:
            cp_num = cp.get('part_number')
            if cp_num not in valid_part_ids:
                errors.append(f"case_001.json references unknown part '{cp_num}'")

        # Cost check
        c1_repair = case_001_data.get('step_6_repair_execution', {})
        if abs((c1_repair.get('parts_cost_inr', 0) + c1_repair.get('labor_cost_inr', 0)) - c1_repair.get('total_cost_inr', 0)) > 0.01:
            errors.append("case_001.json repair cost sum mismatch")

    # 7. Generate Validation Report Markdown
    print("[7/8] Generating validation_report.md...")
    status_str = "PASS" if len(errors) == 0 else "FAIL"
    report_md = f"""# TORQ Data Integrity Validation Report

**Status**: **{status_str}**
**Generated At**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

---

## 1. Summary of Execution

| Metric | Measured Value | Requirement | Status |
| :--- | :--- | :--- | :--- |
| **Total DTC Entries** | {stats.get('total_dtcs', 0)} | 15–20 | {'OK' if 15 <= stats.get('total_dtcs', 0) <= 25 else 'WARNING'} |
| **Total Parts Catalog** | {stats.get('total_parts', 0)} | 15–20 | {'OK' if 15 <= stats.get('total_parts', 0) <= 25 else 'WARNING'} |
| **Total Procedure Docs** | {stats.get('total_procedures', 0)} | 6–8 | {'OK' if 6 <= stats.get('total_procedures', 0) <= 10 else 'WARNING'} |
| **Total Repair Records** | {stats.get('total_repairs', 0)} | ~60 | {'OK' if 55 <= stats.get('total_repairs', 0) <= 65 else 'WARNING'} |
| **TORQ GAP Cases** | {stats.get('gap_cases', 0)} | >= 8 | {'OK' if stats.get('gap_cases', 0) >= 8 else 'FAIL'} |
| **TORQ NOVA Trend Cases** | {stats.get('nova_q3q4_cases', 0)} | Pattern Detected | {'OK' if stats.get('nova_q3q4_cases', 0) >= 5 else 'WARNING'} |
| **TORQ PROVE Cases** | {stats.get('prove_cases', 0)} | 100% Resolved | {'OK' if stats.get('prove_cases', 0) == stats.get('total_repairs', 0) else 'FAIL'} |

---

## 2. Validation Checks & Rule Results

1. **Referential Integrity**: {'PASSED - Zero unmapped DTC or Part IDs' if len(errors) == 0 else 'FAILED'}
2. **Mathematical Accuracy**: {'PASSED - All total_cost_inr == parts_cost + labor_cost' if len(errors) == 0 else 'FAILED'}
3. **JSON & CSV Schema Formatting**: {'PASSED - All files parse cleanly' if len(errors) == 0 else 'FAILED'}
4. **Data Provenance**: {'PASSED - Non-proprietary synthetic markers verified' if len(errors) == 0 else 'FAILED'}
5. **Duplicate Identifier Check**: {'PASSED - Zero duplicate part numbers or case IDs' if len(errors) == 0 else 'FAILED'}

---

## 3. Error Log ({len(errors)} Errors)

"""
    if errors:
        for err in errors:
            report_md += f"- ❌ {err}\n"
    else:
        report_md += "✅ **No errors found. Dataset is 100% compliant and ready for integration.**\n"

    report_md += "\n---\n\n## 4. Recommendations & Warnings\n\n"
    if warnings:
        for warn in warnings:
            report_md += f"- ⚠️ {warn}\n"
    else:
        report_md += "None. All parameters within expected bounds.\n"

    with open(REPORT_PATH, 'w', encoding='utf-8') as f:
        f.write(report_md)

    # 8. Output Status to Shell
    print("[8/8] Validation Complete.")
    print("--------------------------------------------------")
    if errors:
        print(f"RESULT: FAIL ({len(errors)} errors found)")
        for err in errors:
            print(f"  - [ERROR] {err}")
        sys.exit(1)
    else:
        print("RESULT: PASS")
        print(f"Validation report saved to: {REPORT_PATH}")
        sys.exit(0)

if __name__ == '__main__':
    run_validation()
