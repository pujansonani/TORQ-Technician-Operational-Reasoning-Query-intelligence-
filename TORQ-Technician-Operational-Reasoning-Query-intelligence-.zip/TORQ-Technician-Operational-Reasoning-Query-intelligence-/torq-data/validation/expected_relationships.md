# TORQ Dataset Expected Relationships & Entity Graph

**SYNTHETIC DEMONSTRATION DATA — NOT PACCAR PROPRIETARY CONTENT**

---

## Overview
This document defines the strict relational integrity rules, foreign key bindings, and semantic consistency constraints governing the TORQ synthetic dataset.

---

## Entity Relationship Graph (Mermaid)

```mermaid
erDiagram
    DTC_KB ||--o{ REPAIRS : "triggers"
    PARTS ||--o{ REPAIRS : "consumed in"
    PROCEDURES ||--o{ DTC_KB : "guides"
    PROCEDURES ||--o{ DEMO_CASE : "referenced in"
    PARTS ||--o{ DEMO_CASE : "used in"
    DTC_KB ||--o{ DEMO_CASE : "active code in"
    REPAIRS ||--o{ DEMO_CASE : "matches pattern of"
```

---

## 1. Foreign Key & Binding Constraints

### 1.1 `repairs.csv` -> `dtc_kb.csv`
- **Rule**: Every value in `repairs.csv` (`dtc_code` column) MUST exist as a valid `code` entry in `dtc/dtc_kb.csv`.
- **Validation Check**: Unresolved DTC reference error.

### 1.2 `repairs.csv` -> `parts.json`
- **Rule**: Every part ID listed in `repairs.csv` (`parts_used` column, pipe-separated if multiple) MUST exist in `parts/parts.json` under `part_number`.
- **Validation Check**: Unresolved Part ID reference error.

### 1.3 `case_001.json` -> `parts.json` & `dtc_kb.csv`
- **Rule**:
  - `step_1_initial_state.active_dtc.code` MUST exist in `dtc/dtc_kb.csv`.
  - Every `part_number` in `step_6_repair_execution.parts_used` MUST exist in `parts/parts.json`.

---

## 2. Mathematical Integrity Constraints

### 2.1 Repair Cost Calculation
- **Rule**: In `repairs.csv`, for every record:
  $$\text{total\_cost\_inr} = \text{parts\_cost\_inr} + \text{labor\_cost\_inr}$$
- **Validation Check**: Math discrepancy error if $\text{total} \neq \text{parts} + \text{labor}$.

### 2.2 Case 001 Repair Cost Calculation
- **Rule**: In `case_001.json`:
  $$\text{step\_6\_repair\_execution.total\_cost\_inr} = \text{parts\_cost\_inr} + \text{labor\_cost\_inr}$$

---

## 3. Mandatory Pattern Constraints

### 3.1 TORQ GAP Pattern
- **Requirement**: At least 8 historical cases in `repairs.csv` MUST demonstrate the TORQ GAP pattern:
  - `documented_path`: Contains OEM sensor replacement sequence.
  - `actual_path`: Contains connector/wiring inspection, cleaning, or pigtail splice.
  - `root_cause`: Contains `Connector` or `Pin` or `Wiring`.

### 3.2 TORQ NOVA Emerging Trend Pattern
- **Requirement**: Timestamps in `repairs.csv` MUST show a measurable increase in connector-related root causes in later periods (Q3-Q4 2025/2026) for vehicle model `TX-900` running software `v4.2.1`.

### 3.3 TORQ PROVE Evidence
- **Requirement**: 100% of resolved cases (`resolved == true`) MUST contain non-empty `verification_evidence` containing structured `BEFORE:` and `AFTER:` telemetry strings.

---

## 4. Provenance & Safety Constraints

- All CSV, JSON, and Markdown files MUST contain explicit provenance markers:
  - `data_status`: `SYNTHETIC` or `SYNTHETIC_DEMO`
  - Explicit header declaration: `"SYNTHETIC DEMONSTRATION DATA — NOT PACCAR PROPRIETARY CONTENT"`
