# Diagnostic Procedure: Heavy Vehicle Sensor & Electrical Circuit Diagnosis

**SYNTHETIC DEMONSTRATION DATA — NOT PACCAR PROPRIETARY CONTENT**

---

## Metadata
- **Title**: Sensor 5V Reference & Signal Circuit Diagnostic Procedure
- **Document ID**: DOC-PROC-003
- **Data Status**: SYNTHETIC
- **Subsystem**: sensor_electrical
- **Source / Provenance**: SYNTHETIC_DEMO (TORQ Engineering Framework)

---

## Pre-Conditions & Applicable Symptoms
- **Applicable Symptoms**:
  - Intermittent gauge dropouts or erratic sensor readings on dashboard
  - Multiple sensor DTCs active simultaneously (5V reference bus short) or single sensor circuit low code
  - Active DTCs: `P0237`, `P0117`, `P0191`, `P0544`, `P2453`, `DEMO-DTC-101`
- **Operating Conditions**:
  - Key On Engine Off (KOEO).

---

## Candidate Causes
1. **Connector Pin Oxide Corrosion or Female Terminal Fretting** (High probability - TORQ GAP focus)
2. **Isolated Signal Wire Short to Ground or Open Circuit** (High probability - TORQ GAP focus)
3. **5V Reference Circuit Bus Short to Ground in Main Harness** (Moderate probability - multiple DTC signature)
4. **Sensor Component Internal Thermistor/Element Breakdown** (Moderate probability)

---

## Decision Tree & Diagnostic Steps

### Step 1: 5V Reference Bus & Signal Line Integrity Check
- **Action**: Disconnect suspected sensor connector C042. Measure voltage between harness Vref Pin A and battery ground using Digital Multimeter (DMM). Next, measure Signal Pin B voltage.
- **Expected Result (PASS)**:
  - Vref Pin A = 5.00V ± 0.10V. Signal Pin B pull-up voltage is nominal.
  - **Next Branch**: Proceed to **Step 2**.
- **Failure Result (FAIL)**:
  - Vref Pin A = 0.0V (indicates shared 5V Vref Bus short to ground across multiple sensors) OR Signal Pin B pinned at 0.0V (isolated signal line ground short / open).
  - **Branch / Resolution**: If Vref Bus is 0.0V, disconnect remaining sensors on Vref Bus A one by one to isolate shorted harness branch. If Vref is 5.0V PASS but Signal Pin B is 0.0V FAIL, proceed to **Step 2** to inspect signal socket corrosion.

### Step 2: Harness Connector Contact Resistance & Pin Retention Force Check
- **Action**: Insert a new male test pin of matching gauge into female socket pin C042 (Signal Socket B) to check retention drag force. Inspect for green/white oxide buildup.
- **Expected Result (PASS)**:
  - Firm drag force felt (> 1.5 N); pin surface clean with zero oxidation.
  - **Next Branch**: Proceed to **Step 3**.
- **Failure Result (FAIL)**:
  - Loose drag force (< 0.5 N) or visible green copper oxide scale on terminal socket.
  - **Branch / Resolution**: Remove corroded terminal; crimp new sealed terminal pigtail (`DEMO-P-011` / `DEMO-P-012`). Coat with dielectric compound (`DEMO-P-018`). Proceed to **Post-Repair Verification**.

### Step 3: Sensor Component Resistance Bench Test
- **Action**: Measure sensor terminal resistance across Signal and Ground pins using DMM set to Ohms.
- **Expected Result (PASS)**:
  - Resistance matches factory specification table (e.g., 2.5k ohms for ECT at 20°C).
  - **Next Branch**: Sensor electrical circuit nominal.
- **Failure Result (FAIL)**:
  - Resistance infinite (open) or 0 ohms (dead short).
  - **Branch / Resolution**: Replace corresponding sensor (`DEMO-P-001`, `DEMO-P-006`, or `DEMO-P-010`).

---

## Post-Repair Verification (PROVE Criteria)
1. **DTC Status**: Clear sensor DTCs. Turn ignition off for 30 seconds; restart engine.
2. **Telemetry Evidence**:
   - **BEFORE**: Vref = 5.01V PASS, Signal Voltage = 0.12V (Circuit Low) / Signal intermittent dropouts to 0V.
   - **AFTER**: Signal voltage stable within 0.5V - 4.5V nominal sweep; zero voltage dropouts logged.

---

## Safety Notes
> [!CAUTION]
> Always disconnect battery ground cable before performing harness resistance tests to avoid blowing DMM internal fuses or damaging ECM logic gates.
