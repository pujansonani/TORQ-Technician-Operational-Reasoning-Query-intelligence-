# Diagnostic Procedure: Heavy Vehicle Exhaust Aftertreatment (DPF / SCR) Diagnosis

**SYNTHETIC DEMONSTRATION DATA — NOT PACCAR PROPRIETARY CONTENT**

---

## Metadata
- **Title**: Exhaust Aftertreatment DPF, SCR & DEF Dosing System Diagnostic Procedure
- **Document ID**: DOC-PROC-006
- **Data Status**: SYNTHETIC
- **Subsystem**: aftertreatment
- **Source / Provenance**: SYNTHETIC_DEMO (TORQ Engineering Framework)

---

## Pre-Conditions & Applicable Symptoms
- **Applicable Symptoms**:
  - DPF warning light illuminated; frequent forced regeneration prompts
  - DEF fluid quality warning light / vehicle speed derate active
  - Active DTCs: `P2002`, `P2453`, `P20EE`, `P0544`, `P242F`, `DEMO-DTC-103`
- **Operating Conditions**:
  - Engine running; exhaust temperature > 250°C for SCR testing.

---

## Candidate Causes
1. **DEF Dosing Injector Nozzle Tip Crystallization** (High probability)
2. **DPF Differential Pressure Sensor Harness Connector Pin Corrosion or Calibration Drift** (Moderate probability - TORQ GAP focus)
3. **Downstream SCR NOx Sensor Degradation** (Moderate probability)
4. **DPF Substrate Heavy Ash Accumulation or Physical Cracking** (Moderate probability)

---

## Decision Tree & Diagnostic Steps

### Step 1: DEF Doser Nozzle & Fluid Concentration Test
- **Action**: Remove DEF dosing injector (`DEMO-P-013`). Inspect nozzle tip for white urea crystallization buildup. Check DEF fluid concentration with refractometer.
- **Expected Result (PASS)**:
  - Nozzle tip clean and free of white crust; DEF concentration = 32.5% ± 1.5%.
  - **Next Branch**: Proceed to **Step 2**.
- **Failure Result (FAIL)**:
  - Heavy white urea deposits blocking nozzle orifice OR DEF concentration < 30%.
  - **Branch / Resolution**: Clean DEF doser tip with warm deionized water or replace DEF Dosing Injector (`DEMO-P-013`). Drain and flush DEF tank if contaminated. Proceed to **Post-Repair Verification**.

### Step 2: DPF Differential Pressure Sensor & Electrical Inspection
- **Action**: Check DPF Delta P sensor hose ports for blockage. Inspect sensor electrical connector pins for moisture and green oxidation. Compare KOEO Delta P reading (DTC `P2453`).
- **Expected Result (PASS)**:
  - Sensor ports clear of soot/water; pins clean; KOEO Delta P reading = 0.0 PSI ± 0.1 PSI.
  - **Next Branch**: Proceed to **Step 3**.
- **Failure Result (FAIL)**:
  - Sensor pins corroded or KOEO Delta P reading static > 0.5 PSI (calibration drift).
  - **Branch / Resolution**: Clean connector pins (`DEMO-P-018`) or replace DPF Differential Pressure Sensor (`DEMO-P-008`). Proceed to **Post-Repair Verification**.

### Step 3: SCR NOx Conversion Efficiency & Sensor Test
- **Action**: Monitor inlet NOx sensor (SPN 3216) vs outlet NOx sensor (SPN 3226) during stationary regeneration.
- **Expected Result (PASS)**:
  - Outlet NOx reading drops > 85% below inlet NOx reading during active dosing.
  - **Next Branch**: Aftertreatment system operating nominally.
- **Failure Result (FAIL)**:
  - Outlet NOx reading remains nearly equal to inlet NOx reading (NOx conversion < 50%).
  - **Branch / Resolution**: Replace SCR NOx Sensor Outlet (`DEMO-P-009`) or EGT Sensor (`DEMO-P-014`). If DPF substrate is physically cracked (black soot in tailpipe with DTC `P2002`), clean or replace DPF filter core.

---

## Post-Repair Verification (PROVE Criteria)
1. **DTC Status**: Clear DTCs `P2002`, `P2453`, `P20EE`, `P242F`. Perform stationary DPF regeneration.
2. **Telemetry Evidence**:
   - **BEFORE**: SCR NOx conversion efficiency 42%; DPF Delta P = 5.8 PSI.
   - **AFTER**: SCR NOx conversion efficiency 91.5%; DPF Delta P = 0.8 PSI post-regen.

---

## Safety Notes
> [!CAUTION]
> Exhaust pipes and aftertreatment components reach temperatures exceeding 550°C during active regeneration. Wear thermal safety gloves and keep clear of tailpipe discharge.
