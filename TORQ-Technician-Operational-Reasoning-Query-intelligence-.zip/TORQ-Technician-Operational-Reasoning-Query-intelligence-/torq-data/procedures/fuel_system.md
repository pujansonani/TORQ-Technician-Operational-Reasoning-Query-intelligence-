# Diagnostic Procedure: Heavy Vehicle High Pressure Fuel System Diagnosis

**SYNTHETIC DEMONSTRATION DATA — NOT PACCAR PROPRIETARY CONTENT**

---

## Metadata
- **Title**: Common Rail Fuel System Pressure & Fuel Delivery Diagnostic Procedure
- **Document ID**: DOC-PROC-005
- **Data Status**: SYNTHETIC
- **Subsystem**: fuel_system
- **Source / Provenance**: SYNTHETIC_DEMO (TORQ Engineering Framework)

---

## Pre-Conditions & Applicable Symptoms
- **Applicable Symptoms**:
  - Engine cranking for extended duration before start (hard start)
  - Engine stalling or surging under load
  - Insufficient fuel rail pressure warning
  - Active DTCs: `P0087`, `P0191`
- **Operating Conditions**:
  - Fuel level above 25%; engine crank and idle checks.

---

## Candidate Causes
1. **Primary/Secondary Fuel Filter Restriction** (High probability)
2. **Fuel Rail Pressure Sensor Wiring / Connector Fault** (Moderate probability - TORQ GAP focus)
3. **High Pressure Fuel Pump (HPFP) Mechanical Wear** (Moderate probability)
4. **Fuel Injector High Return Flow Leakage** (Low probability)

---

## Decision Tree & Diagnostic Steps

### Step 1: Low-Pressure Fuel Delivery & Filter Restriction Check
- **Action**: Measure low-pressure gear pump delivery pressure before HPFP inlet at cranking and 1800 RPM.
- **Expected Result (PASS)**:
  - Supply pressure > 65 PSI (448 kPa) at 1800 RPM.
  - **Next Branch**: Proceed to **Step 2**.
- **Failure Result (FAIL)**:
  - Supply pressure < 45 PSI (310 kPa); pressure drops rapidly under load.
  - **Branch / Resolution**: Replace primary and secondary fuel filter dual kit (`DEMO-P-016`). Drain water separator bowl. Proceed to **Post-Repair Verification**.

### Step 2: Fuel Rail Sensor Voltage & Pin Integrity Check
- **Action**: Check sensor reference voltage (5.0V) and inspect connector C014 pins for green corrosion or pushed pins.
- **Expected Result (PASS)**:
  - Connector C014 clean; KOEO signal voltage = 0.50V (corresponding to 0 PSI gauge).
  - **Next Branch**: Proceed to **Step 3**.
- **Failure Result (FAIL)**:
  - Connector pins show oxide scale or signal voltage reads > 1.2V at KOEO (fake high pressure reading).
  - **Branch / Resolution**: Clean connector pins or splice repair pigtail (`DEMO-P-011` / `DEMO-P-012`). If sensor element is internally shorted, replace Fuel Rail Sensor (`DEMO-P-006`). Proceed to **Post-Repair Verification**.

### Step 3: High Pressure Pump (HPFP) & Rail Pressure Test
- **Action**: Command maximum rail pressure test using service tool. Measure actual rail pressure vs target rail pressure.
- **Expected Result (PASS)**:
  - Actual rail pressure reaches target 2200 bar (31,900 PSI) within 1.5 seconds.
  - **Next Branch**: Fuel system nominal.
- **Failure Result (FAIL)**:
  - Rail pressure maxes out at 1400 bar despite 100% pump quantity control valve command.
  - **Branch / Resolution**: Replace HPFP Assembly (`DEMO-P-005`).

---

## Post-Repair Verification (PROVE Criteria)
1. **DTC Status**: Clear DTCs `P0087`, `P0191`.
2. **Telemetry Evidence**:
   - **BEFORE**: Fuel rail pressure limited to 950 bar; crank time > 8 seconds.
   - **AFTER**: Rail pressure reaches 2200 bar target; engine starts in < 1.8 seconds.

---

## Safety Notes
> [!CAUTION]
> High pressure fuel rails operate at pressures exceeding 2,000 bar (29,000 PSI). Never loosen fuel fittings while engine is cranking or running. Fluid under pressure can penetrate skin and cause severe injury.
