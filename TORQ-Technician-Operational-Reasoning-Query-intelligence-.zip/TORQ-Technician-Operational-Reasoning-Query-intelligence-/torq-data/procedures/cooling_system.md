# Diagnostic Procedure: Heavy Vehicle Engine Cooling System Diagnosis

**SYNTHETIC DEMONSTRATION DATA — NOT PACCAR PROPRIETARY CONTENT**

---

## Metadata
- **Title**: Heavy Duty Engine Cooling System & Temperature Sensor Diagnostic Procedure
- **Document ID**: DOC-PROC-007
- **Data Status**: SYNTHETIC
- **Subsystem**: cooling_system
- **Source / Provenance**: SYNTHETIC_DEMO (TORQ Engineering Framework)

---

## Pre-Conditions & Applicable Symptoms
- **Applicable Symptoms**:
  - Engine coolant temperature gauge reading abnormally high or low
  - Cooling fan running at 100% continuous high speed
  - Active DTCs: `P0117`
- **Operating Conditions**:
  - Engine cool before opening cap; warm to test thermostat opening.

---

## Candidate Causes
1. **Engine Coolant Temperature (ECT) Sensor Wire Short to Ground / Connector Corrosion** (High probability - TORQ GAP focus)
2. **ECT Sensor Internal Thermistor Failure** (Moderate probability)
3. **Thermostat Stuck Closed or Opening Late** (Moderate probability)
4. **Radiator External Soot / Debris Clogging** (Low probability)

---

## Decision Tree & Diagnostic Steps

### Step 1: ECT Sensor Electrical Circuit & Connector Check
- **Action**: Disconnect ECT sensor harness connector. Measure voltage at harness connector pin with KOEO. Inspect pins for corrosion or short to ground.
- **Expected Result (PASS)**:
  - Voltage = 5.0V Vref; connector pins clean and dry.
  - **Next Branch**: Proceed to **Step 2**.
- **Failure Result (FAIL)**:
  - Voltage = 0.0V (harness short to ground) OR green corrosion bridge on socket pins.
  - **Branch / Resolution**: Repair harness wire insulation or clean/replace connector socket (`DEMO-P-011` / `DEMO-P-012`). Proceed to **Post-Repair Verification**.

### Step 2: ECT Thermistor Resistance Bench Check
- **Action**: Measure ECT sensor resistance across terminals at ambient temperature (20°C).
- **Expected Result (PASS)**:
  - Resistance = 2,400 to 2,600 ohms at 20°C.
  - **Next Branch**: Proceed to **Step 3**.
- **Failure Result (FAIL)**:
  - Resistance < 50 ohms or infinite (open).
  - **Branch / Resolution**: Replace ECT Sensor (`DEMO-P-010`). Proceed to **Post-Repair Verification**.

### Step 3: Thermostat Opening Temperature Verification
- **Action**: Warm engine and monitor upper radiator hose temperature using infrared pyrometer vs ECM ECT live parameter.
- **Expected Result (PASS)**:
  - Upper radiator hose suddenly warms when ECT reaches 82°C (180°F), indicating thermostat crack-open.
  - **Next Branch**: Cooling system operating nominally.
- **Failure Result (FAIL)**:
  - Upper hose remains cold while ECT exceeds 98°C.
  - **Branch / Resolution**: Replace Heavy Duty Thermostat Assembly (`DEMO-P-015`).

---

## Post-Repair Verification (PROVE Criteria)
1. **DTC Status**: Clear DTC `P0117`.
2. **Telemetry Evidence**:
   - **BEFORE**: ECT signal pegged at 125°C (short) / Fan locked high.
   - **AFTER**: ECT reading steady at 85°C; fan cycles normally.

---

## Safety Notes
> [!CAUTION]
> Never open radiator surge tank cap when engine is hot. Scalding coolant under pressure can spray out and cause severe burns.
