# Diagnostic Procedure: Heavy Vehicle Wiring & Connector Integrity Diagnostic Procedure

**SYNTHETIC DEMONSTRATION DATA — NOT PACCAR PROPRIETARY CONTENT**

---

## Metadata
- **Title**: Heavy Vehicle Connector Pin Corrosion & Harness Inspection Procedure
- **Document ID**: DOC-PROC-004
- **Data Status**: SYNTHETIC
- **Subsystem**: wiring_connector
- **Source / Provenance**: SYNTHETIC_DEMO (TORQ Engineering Framework)

---

## Pre-Conditions & Applicable Symptoms
- **Applicable Symptoms**:
  - Intermittent sensor faults occurring when vehicle travels over bumps or in wet weather
  - Spurious fault codes popping up simultaneously across multiple engine sensors
  - Unresolved DTCs despite sensor replacement (TORQ GAP signature)
  - Active DTCs: `P0237`, `P0191`, `P0069`, `DEMO-DTC-101`
- **Operating Conditions**:
  - Ignition OFF for physical harness checks; KOEO for voltage wiggle tests.

---

## Candidate Causes
1. **Weatherpack Connector Seal Degradation & Moisture Ingress** (High probability - TORQ GAP focus)
2. **Terminal Pin Oxide Scale / Fretting Corrosion** (High probability - TORQ GAP focus)
3. **Harness Wire Rub-Through / Chafing against Engine Frame Rail** (Moderate probability)
4. **Improper Connector Latching / Secondary Lock Disengaged** (Low probability)

---

## Decision Tree & Diagnostic Steps

### Step 1: Connector Housing Visual & Mechanical Latch Check
- **Action**: Inspect external housing of connector C042 / C014. Check rubber seal integrity and secondary CPA (Connector Position Assurance) lock clip.
- **Expected Result (PASS)**:
  - Connector lock fully latched; rubber wire seals pliable and intact without tears or missing plugs.
  - **Next Branch**: Proceed to **Step 2**.
- **Failure Result (FAIL)**:
  - CPA latch broken; missing connector seal allowing water ingress; housing cracked.
  - **Branch / Resolution**: Replace connector body assembly using repair kit (`DEMO-P-011`).

### Step 2: Pin Terminal Oxidation Inspection & Pin Pull Test
- **Action**: Unlatch connector. Inspect male pins and female sockets under magnification for blue/green copper corrosion or white zinc scale. Perform individual wire pull test (pull gently on wire with 5 N force to test terminal retention).
- **Expected Result (PASS)**:
  - Pin surfaces clean, bright, dry. Wire terminals remain securely locked in housing connector cavity.
  - **Next Branch**: Proceed to **Step 3**.
- **Failure Result (FAIL)**:
  - Visible green oxidation on socket C042 Pin B; terminal pulls back out of connector housing under light force.
  - **Branch / Resolution**: Cut corroded terminal back to clean copper wire. Crimp new gold-plated terminal socket (`DEMO-P-011` / `DEMO-P-012`). Pack cavity with dielectric grease (`DEMO-P-018`). Proceed to **Post-Repair Verification**.

### Step 3: Dynamic Wiggle Test & Continuity Check
- **Action**: Monitor live sensor voltage on diagnostic software while physically wiggling and shaking harness branch every 100mm.
- **Expected Result (PASS)**:
  - Voltage remains perfectly steady (e.g. 5.00V Vref, 1.25V signal) during vigorous harness agitation.
  - **Next Branch**: Wiring branch verified nominal.
- **Failure Result (FAIL)**:
  - Voltage spikes to 0V or 5V when specific harness elbow is flexed.
  - **Branch / Resolution**: Strip harness loom around affected flex point; repair broken wire strand or replace harness pigtail (`DEMO-P-012`).

---

## Post-Repair Verification (PROVE Criteria)
1. **DTC Status**: Clear active DTCs. Perform 10-minute road test on rough road section.
2. **Telemetry Evidence**:
   - **BEFORE**: Signal voltage drops to 0V during harness wiggle; 14 active error counts logged.
   - **AFTER**: 0 voltage dropouts logged; signal stays within nominal range during wiggle test.

---

## Safety Notes
> [!CAUTION]
> Avoid pulling directly on thin sensor wires with excessive force. Use appropriate pin release tools when removing terminals to prevent breaking plastic housing retaining tabs.
