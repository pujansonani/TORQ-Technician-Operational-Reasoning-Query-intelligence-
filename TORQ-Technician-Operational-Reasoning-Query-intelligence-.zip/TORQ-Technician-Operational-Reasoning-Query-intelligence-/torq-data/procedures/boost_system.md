# Diagnostic Procedure: Heavy Vehicle Turbocharger & Boost System Diagnosis

**SYNTHETIC DEMONSTRATION DATA — NOT PACCAR PROPRIETARY CONTENT**

---

## Metadata
- **Title**: Turbocharger Boost System & Air Charge Leakage Diagnostic Procedure
- **Document ID**: DOC-PROC-001
- **Data Status**: SYNTHETIC
- **Subsystem**: boost_system
- **Source / Provenance**: SYNTHETIC_DEMO (TORQ Engineering Framework)

---

## Pre-Conditions & Applicable Symptoms
- **Applicable Symptoms**:
  - Loss of engine power under load (incline / acceleration)
  - Excessive black exhaust smoke under boost demand
  - Whistling or hissing noise from engine bay during acceleration
  - Active DTCs: `P0237`, `P0299`, `P0234`, `P2263`, `DEMO-DTC-101`
- **Operating Conditions**:
  - Engine at normal operating temperature (80°C - 90°C)
  - Vehicle stationary with parking brake engaged for static tests; chassis dyno or road test for dynamic boost logs.

---

## Candidate Causes
1. **Charge Air Cooler (CAC) Leakage or Hose Disconnection** (High probability)
2. **Boost Pressure Sensor / MAP Sensor Harness Connector Pin Corrosion** (High probability - TORQ GAP focus)
3. **Boost Pressure Sensor Calibration Drift or Internal Failure** (Moderate probability)
4. **Turbocharger VGT Actuator Sticking or Electrical Solenoid Failure** (Moderate probability)
5. **Turbocharger Mechanical Impeller Damage** (Low probability)

---

## Decision Tree & Diagnostic Steps

### Step 1: Visual & Mechanical Charge Air System Leakage Inspection
- **Action**: Pressure test Charge Air Cooler (CAC) and piping system at 15 PSI (103 kPa) using CAC pressure test tool.
- **Expected Result (PASS)**:
  - System holds 15 PSI for 5 minutes without dropping more than 0.5 PSI.
  - **Next Branch**: Proceed to **Step 2**.
- **Failure Result (FAIL)**:
  - System drops > 2.0 PSI within 1 minute; audible air hiss detected at silicone boots, clamps, or CAC end tanks.
  - **Branch / Resolution**: Replace damaged CAC hose kit (`DEMO-P-002`) or tighten clamps to spec. Proceed to **Post-Repair Verification**.

### Step 2: Boost Sensor Electrical Vref & Harness Pin Corrosion Check
- **Action**: Disconnect Boost Sensor harness connector C042. Measure Reference Voltage (Vref) between Pin A and Pin C with Key On Engine Off (KOEO). Inspect female socket pins for green copper oxide corrosion, fretting, or pushed-back pins.
- **Expected Result (PASS)**:
  - Vref = 5.0V ± 0.1V. Pins are clean, bright, shiny silver/gold with firm pin retention force (> 1.5 N).
  - **Next Branch**: Proceed to **Step 3**.
- **Failure Result (FAIL)**:
  - Vref < 4.5V OR visual green corrosion / fretting corrosion present on Pin B (Signal) or Pin C (Ground); pin retention force weak.
  - **Branch / Resolution**: Execute connector pin de-corrosion, pin tension adjustment, or splice replacement pigtail (`DEMO-P-011` / `DEMO-P-012`). Apply dielectric grease (`DEMO-P-018`). (Note: Do NOT replace sensor unless internal short is confirmed). Proceed to **Post-Repair Verification**.

### Step 3: Boost Sensor Dynamic Signal vs Manifold Absolute Pressure Verification
- **Action**: Monitor live ECM data stream for Boost Pressure (SPN 102) vs calibrated master mechanical gauge at 1800 RPM full dyno load.
- **Expected Result (PASS)**:
  - Sensor reading matches mechanical gauge within ± 0.8 PSI (nominal peak 28.5 PSI).
  - **Next Branch**: Proceed to **Step 4**.
- **Failure Result (FAIL)**:
  - Sensor reading static (e.g., stuck at 0.5V or 4.8V) while mechanical gauge reads 28 PSI.
  - **Branch / Resolution**: Replace Boost Pressure Sensor (`DEMO-P-001`). Proceed to **Post-Repair Verification**.

### Step 4: VGT Actuator / Wastegate Linkage Sweep Test
- **Action**: Perform service tool bi-directional test: sweep VGT actuator position from 0% to 100%.
- **Expected Result (PASS)**:
  - Actuator moves smoothly across full range without binding or position feedback deviation.
  - **Next Branch**: System nominal; investigate fuel supply or exhaust backpressure.
- **Failure Result (FAIL)**:
  - Actuator binds at 35% position or DTC `P2263` / `P0045` active.
  - **Branch / Resolution**: Replace VGT Actuator (`DEMO-P-003`) or Wastegate Solenoid (`DEMO-P-017`).

---

## Repair Guidance
- **For Wiring/Connector Faults**: Cut damaged pin section 50mm back from connector body. Crimp new sealed Weatherpack pin terminals using ratchet crimper. Insert into new housing (`DEMO-P-011`). Apply corrosion preventive compound (`DEMO-P-018`).
- **For Hose Replacements**: Clean mating aluminum hose beads with solvent before installing silicone boots (`DEMO-P-002`). Torque T-bolt clamps to 8.5 Nm.

---

## Post-Repair Verification (PROVE Criteria)
1. **DTC Status**: Clear active and pending DTCs (`P0237`, `P0299`). Perform 2 warm-up cycles; confirm zero active DTCs.
2. **Telemetry Evidence**:
   - **BEFORE**: Boost pressure limited to < 14.5 PSI under load; engine power derated 40%.
   - **AFTER**: Peak boost pressure reaches 28.2 - 28.8 PSI at 1800 RPM under load; fuel rate reaches nominal rating.

---

## Safety Notes
> [!CAUTION]
> - Charge air pipes become hot during operation (> 120°C). Allow engine to cool before handling.
> - High pressure air test (15 PSI) can cause unrestrained hoses to blow off violently. Secure all test plugs with safety straps.
