# Diagnostic Procedure: Heavy Vehicle Intake System & EGR Diagnostic Procedure

**SYNTHETIC DEMONSTRATION DATA — NOT PACCAR PROPRIETARY CONTENT**

---

## Metadata
- **Title**: Engine Air Intake Restriction & EGR System Diagnostic Procedure
- **Document ID**: DOC-PROC-002
- **Data Status**: SYNTHETIC
- **Subsystem**: intake_system
- **Source / Provenance**: SYNTHETIC_DEMO (TORQ Engineering Framework)

---

## Pre-Conditions & Applicable Symptoms
- **Applicable Symptoms**:
  - Sluggish throttle response at low RPM
  - Excessive intake air restriction indicator warning
  - High EGR soot buildup / premature DPF regens
  - Active DTCs: `P0069`, `P0101`, `P0401`, `DEMO-DTC-102`
- **Operating Conditions**:
  - Engine idle and rated RPM static checks.

---

## Candidate Causes
1. **Air Filter Element Clogging or Duct Collapse** (High probability)
2. **Mass Air Flow (MAF) Sensor Sensing Element Contamination** (Moderate probability)
3. **EGR Valve Actuator Soot Binding / Carbon Accumulation** (High probability)
4. **EGR Differential Pressure Sensor Port Blockage** (Moderate probability)

---

## Decision Tree & Diagnostic Steps

### Step 1: Intake Restriction & Filter Inspection
- **Action**: Check primary air filter restriction gauge. Inspect air intake filter element and ducting for collapse or foreign debris.
- **Expected Result (PASS)**:
  - Restriction indicator < 15 inches H2O; filter clean.
  - **Next Branch**: Proceed to **Step 2**.
- **Failure Result (FAIL)**:
  - Restriction indicator > 25 inches H2O; filter heavily loaded with dust/debris.
  - **Branch / Resolution**: Replace primary air filter element. Clean intake filter housing. Proceed to **Post-Repair Verification**.

### Step 2: MAF Sensor Signal & Connector Pin Inspection
- **Action**: Inspect MAF sensor hot-wire element for oil/dust coating. Check MAF connector terminal pins for fretting or loose fit.
- **Expected Result (PASS)**:
  - Sensor wire clean; connector pins bright silver; KOEO MAF reading matches 0 g/s.
  - **Next Branch**: Proceed to **Step 3**.
- **Failure Result (FAIL)**:
  - Sensor wire coated with oil/dirt or connector pin loose.
  - **Branch / Resolution**: Clean MAF sensor wire with zero-residue aerosol cleaner. If signal remains erratic, replace MAF sensor (`DEMO-P-004`). Proceed to **Post-Repair Verification**.

### Step 3: EGR Valve Sweeping & Position Feedback Verification
- **Action**: Perform service tool bi-directional command of EGR valve position (0% to 100%).
- **Expected Result (PASS)**:
  - EGR valve position feedback tracks commanded position within ± 3%.
  - **Next Branch**: System nominal; check downstream exhaust components.
- **Failure Result (FAIL)**:
  - Valve feedback lags command by > 15% or valve sticks at 0% open position (DTC `P0401` / `DEMO-DTC-102`).
  - **Branch / Resolution**: Remove EGR valve body; clean carbon soot deposits or replace EGR valve assembly (`DEMO-P-007`).

---

## Post-Repair Verification (PROVE Criteria)
1. **DTC Status**: Clear DTCs `P0069`, `P0101`, `P0401`.
2. **Telemetry Evidence**:
   - **BEFORE**: Air intake restriction > 22 in. H2O; EGR position error 18%.
   - **AFTER**: Intake restriction < 8 in. H2O; EGR position error < 1.5% across full load range.

---

## Safety Notes
> [!CAUTION]
> Never spray flammable aerosol cleaners directly into an operating engine intake. Turn off ignition before cleaning MAF element.
