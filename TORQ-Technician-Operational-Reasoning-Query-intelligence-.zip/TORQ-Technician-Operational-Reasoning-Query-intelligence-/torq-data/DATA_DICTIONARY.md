# TORQ Master Data Dictionary

**SYNTHETIC DEMONSTRATION DATA — NOT PACCAR PROPRIETARY CONTENT**

---

## Executive Overview
This document provides complete schema descriptions, data types, field definitions, representative examples, and TORQ application consumption mappings for every file within the `torq-data/` repository.

---

## 1. Diagnostic Trouble Code Base (`dtc/dtc_kb.csv`)

This dataset provides diagnostic definitions for Suspect Parameter Numbers (SPN) and Failure Mode Identifiers (FMI).

| Field Name | Data Type | Purpose | Example | Consuming TORQ Component |
| :--- | :--- | :--- | :--- | :--- |
| `code` | `string` | Primary key code identifier | `"P0237"` | RAG Retriever / State Engine |
| `spn` | `integer` | J1939 Suspect Parameter Number | `102` | Telemetry Ingestion Engine |
| `fmi` | `integer` | J1939 Failure Mode Identifier | `4` | Telemetry Ingestion Engine |
| `description` | `string` | Formal diagnostic title | `"Boost Pressure Sensor Circuit Low"` | UI Diagnostic Card |
| `subsystem` | `string` | Engine subsystem classification | `"boost_system"` | Cause Prioritization Ranker |
| `severity` | `enum` | Fault criticality (`CRITICAL`, `HIGH`, `MODERATE`, `LOW`) | `"HIGH"` | Safety & Triage Module |
| `symptom_keywords` | `pipe_string` | Keywords matching field symptoms | `"loss of power\|black smoke"` | Natural Language Symptom Matcher |
| `possible_causes` | `pipe_string` | Candidate failure modes | `"sensor low\|connector corroded"` | Probabilistic Cause Ranker |
| `diagnostic_tests` | `pipe_string` | Recommended diagnostic procedures | `"Measure Vref\|Inspect Pin C042"` | Next-Best Test Generator |
| `expected_results` | `string` | Nominal pass condition criteria | `"Vref = 5.0V ± 0.1V"` | Test Result Validator |
| `failure_results` | `string` | Non-nominal failure criteria | `"Signal Voltage < 0.2V or Vref < 4.5V"` | Test Result Validator |
| `repair_actions` | `pipe_string` | Recommended resolution actions | `"Splice pigtail\|Replace sensor"` | Repair Guidance Module |
| `source_type` | `enum` | Provenance category (`PUBLIC_STANDARD`, `SYNTHETIC_DEMO`) | `"PUBLIC_STANDARD"` | Provenance & Safety Filter |
| `source_reference` | `string` | Standard citation | `"SAE J1939 SPN 102 FMI 4"` | Provenance & Audit Log |
| `data_status` | `enum` | Legal status (`VERIFIED_PUBLIC`, `SYNTHETIC`) | `"VERIFIED_PUBLIC"` | Legal Guardrail System |

---

## 2. Parts Catalog (`parts/parts.json`)

Stores synthetic spare component metadata used for repair cost estimations and parts ordering.

| Field Name | Data Type | Purpose | Example | Consuming TORQ Component |
| :--- | :--- | :--- | :--- | :--- |
| `part_number` | `string` | Unique synthetic part identifier | `"DEMO-P-011"` | Inventory / Costing Engine |
| `description` | `string` | Nomenclature of part | `"Weatherpack 4-Pin Repair Kit"` | Tech Action Card / Parts List |
| `price_inr` | `number` | Item cost in Indian Rupees (INR) | `1800` | Repair Cost Calculator |
| `compatible_models`| `array[string]`| Supported heavy vehicle models | `["TX-800", "TX-900"]` | Vehicle Compatibility Filter |
| `subsystem` | `string` | Target subsystem | `"wiring_connector"` | Subsystem Filter |
| `data_status` | `enum` | Legal status (`SYNTHETIC`) | `"SYNTHETIC"` | Legal Guardrail System |

---

## 3. Historical Repair Dataset (`repairs/repairs.csv`)

Contains 60 synthetic historical repair cases used to train RAG embeddings, calculate cause probabilities, and detect field patterns.

| Field Name | Data Type | Purpose & Detailed Explanation | Example | Consuming TORQ Component |
| :--- | :--- | :--- | :--- | :--- |
| `case_id` | `string` | Unique historical case ID | `"CASE-HIST-001"` | Vector DB / Graph DB |
| `vehicle_model` | `string` | Commercial vehicle model code | `"TX-900"` | TORQ NOVA Trend Engine |
| `engine` | `string` | Heavy diesel engine nomenclature | `"MX-13 Synthetic"` | Metadata Filter |
| `mileage_km` | `integer` | Vehicle odometer reading | `145200` | Reliability Analytics |
| `software_version` | `string` | Engine Control Module software version | `"v4.2.1"` | TORQ NOVA Trend Engine |
| `symptom` | `string` | Driver reported symptom | `"Truck loses power climbing incline"` | Natural Language RAG Matcher |
| `dtc_code` | `string` | Active fault code at intake | `"P0237"` | DTC Similarity Engine |
| `documented_path` | `string` | **Standard OEM manual path**: Theoretical sequence prescribed in service documentation. Often blindly orders replacing sensors. | `"DTC P0237 -> Voltage Test -> Replace Boost Sensor"` | **TORQ GAP Engine** (Compares documented vs field actuals) |
| `actual_path` | `string` | **Real field path**: Actual diagnostic steps executed by experienced technician in the shop. | `"DTC P0237 -> Vref PASS -> Connector Pin C042 -> Clean/Splice Pigtail"` | **TORQ GAP Engine** (Provides field truth) |
| `tests_performed` | `pipe_string` | List of tests executed | `"Vref Test\|Pin Pull Test"` | Test Recommendation Engine |
| `root_cause` | `string` | **Confirmed root cause**: Verified physical failure mechanism. | `"Connector C042 Pin B Corrosion"` | Cause Re-Ranking Engine |
| `repair_action` | `string` | Physical repair executed | `"Cleaned socket & crimped repair kit"` | Action Recommendation Card |
| `parts_used` | `pipe_string` | Part IDs consumed in repair | `"DEMO-P-011\|DEMO-P-012"` | Cost Analytics & GAP Engine |
| `labor_hours` | `float` | Billable technician hours | `2.5` | Cost Estimator |
| `parts_cost_inr` | `number` | Sum cost of parts in INR | `6250` | Cost Estimator |
| `labor_cost_inr` | `number` | Total labor charge in INR | `3750` | Cost Estimator |
| `total_cost_inr` | `number` | Total billable repair cost | `10000` | Cost Estimator |
| `resolved` | `boolean` | Success outcome flag | `true` | Repair Success Classifier |
| `verification_evidence`| `string` | **Telemetry evidence**: Quantifiable BEFORE and AFTER metrics confirming repair. | `"BEFORE: Signal 0.12V, Boost 0.0 PSI. AFTER: Signal 4.15V, Boost 28.5 PSI"` | **TORQ PROVE Engine** (Validates repair efficacy) |
| `created_at` | `timestamp` | ISO timestamp of repair completion | `"2025-01-15T09:30:00Z"` | **TORQ NOVA Engine** (Temporal trend detection) |
| `data_status` | `enum` | Always `SYNTHETIC_DEMO` | `"SYNTHETIC_DEMO"` | Safety Filter |

---

## 4. Main Demo State Case (`demo/case_001.json`)

Structured JSON state graph representing the interactive 9-stage journey of `CASE-001`. Consumed directly by the frontend state machine to drive live hackathon demonstrations.
