# TORQ Live Demo Walkthrough — Case 001

**SYNTHETIC DEMONSTRATION DATA — NOT PACCAR PROPRIETARY CONTENT**

This document provides the exact presenter script, input steps, telemetry checkpoints, and feature callouts for demonstrating TORQ during hackathon judging.

---

## Demo Overview
- **Scenario**: Heavy commercial truck (`TX-900`, 158,900 km, software `v4.2.1`) experiencing severe power loss while hauling cargo up a 6% incline.
- **Active Fault**: `DTC P0237` (Turbocharger Boost Pressure Sensor A Circuit Low).
- **Core Narrative**: Show how TORQ prevents an unnecessary ₹12,500 sensor replacement, guides the tech to inspect connector pin `C042` (repair cost ₹1,800 pigtail kit), proves repair success via telemetry (PROVE), surface historical manual mismatch (GAP), and flags an emerging fleet-wide quality trend (NOVA).

---

## Step-by-Step Presentation Script

### Act 1: Initial Symptom & Telemetry Ingestion (UNDERSTAND & RETRIEVE)
1. **Presenter Action**: Enter Symptom and active fault code into TORQ UI:
   - **Symptom Input**: `"Truck loses power when climbing an incline under heavy load"`
   - **Active DTC**: `P0237` (SPN 102 / FMI 4)
2. **Presenter Script**:
   > *"Notice how TORQ immediately ingests the reported symptom and active fault code. Rather than blindly prompting us to replace the boost sensor as a traditional chatbot or standard OEM manual might, TORQ queries our diagnostic decision trees (`procedures/boost_system.md`) and historical field repair database."*
3. **TORQ Display Checkpoint**:
   - Initial Cause Ranking:
     - 1. Harness Connector C042 Corrosion / Pin Tension (35%)
     - 2. Charge Air Cooler Hose Leakage (30%)
     - 3. Boost Pressure Sensor Internal Failure (25%)
     - 4. VGT Actuator Binding (10%)

---

### Act 2: Next-Best Diagnostic Test (RECOMMEND & TEST)
1. **Presenter Action**: Click **"Execute Recommended Test"**.
2. **TORQ Recommendation Screen**:
   - **Test Recommended**: `TEST-PROC-001-STEP2` — Boost Sensor Vref Voltage & Harness Pin C042 Inspection.
   - **Instructions Displayed**: *"Measure Vref between Pin A and Pin C (KOEO). Unlatch connector C042 and check female socket B for green oxidation and pin retention drag force."*
3. **Technician Interaction (Input Result)**:
   - Select **Vref Voltage**: `5.01V (PASS)`
   - Select **Connector Pin C042 Inspection**: `Green Copper Oxide Found / Retention Drag FAIL`
4. **Presenter Script**:
   > *"The technician performs the 10-minute non-invasive test. Vref power supply is 5.01V PASS, but signal pin C042 exhibits green oxidation and loose retention force. When we submit this result, watch TORQ update its probabilistic cause graph in real time."*

---

### Act 3: Dynamic State Update & Pinpoint Cause (UPDATE & CONFIRM)
1. **TORQ Display Checkpoint**:
   - Cause Ranking Re-Weighted:
     - **Connector Pin C042 Corrosion**: **98% (CONFIRMED ROOT CAUSE)**
     - Boost Sensor Replacement: **1% (RULED OUT)**
2. **Presenter Script**:
   > *"TORQ instantly re-ranks the candidates! Replacing the ₹12,500 sensor is now ruled out. TORQ recommends crimping a Weatherpack sealed 4-pin repair kit (`DEMO-P-011`) and replacing the pigtail (`DEMO-P-012`)."*

---

### Act 4: Repair & Telemetry Verification (REPAIR & PROVE)
1. **Presenter Action**: Select **"Execute Repair: Connector Pigtail Splice"** and click **"Verify Repair Telemetry"**.
2. **TORQ PROVE Screen Display**:
   - **DTC Status**: Cleared (0 active codes)
   - **Pre-Repair Telemetry**: Signal 0.12V | Boost Default 0.0 PSI | Derate 40%
   - **Post-Repair Telemetry**: Signal 4.15V | Boost Pressure 28.5 PSI (Nominal) | Derate 0%
3. **Presenter Script**:
   > *"TORQ PROVE verifies that the repair wasn't just cleared in software, but backed by hard telemetry evidence: manifold pressure is fully restored to 28.5 PSI at rated load."*

---

### Act 5: Advanced Intelligence (GAP & NOVA)
1. **Presenter Action**: Open **"Intelligence Insights"** tab.
2. **TORQ GAP Display**:
   - **Documented OEM Manual Path**: `DTC P0237 -> Replace Boost Sensor (DEMO-P-001) [₹12,500]`
   - **Actual Field Path**: `DTC P0237 -> Vref PASS -> Connector C042 Pin Repair [₹6,250]`
   - **Field Savings**: ₹6,250 saved per vehicle | 14 matching historical cases found.
3. **TORQ NOVA Display**:
   - **Alert Banner**: `Emerging pattern detected — engineering review recommended.`
   - **Insight Text**: *"Connector C042 oxidation failure rate increased from 10% in Q1 2025 to 46% in Q3 2026 across TX-900 models with software v4.2.1."*
4. **Closing Presenter Statement**:
   > *"TORQ not only solved the immediate service bay issue in 15 minutes, but also identified a ₹6,250 cost GAP vs static manuals, and surfaced a critical NOVA fleet trend for vehicle design engineers!"*

---

## Quick Reference Summary Table for Live Presenter

| Demo Stage | Action / Input | Expected TORQ Output | Key Metric / Callout |
| :--- | :--- | :--- | :--- |
| **Stage 1** | Enter Symptom + DTC `P0237` | Initial candidate ranking | Connector corrosion prioritized at 35% |
| **Stage 2** | Execute `TEST-PROC-001-STEP2` | Displays test instructions | Vref & Pin C042 drag test |
| **Stage 3** | Input Vref=5.01V, Pin=Corroded | Cause re-ranking | Connector fault jumps to 98% |
| **Stage 4** | Apply `DEMO-P-011` Repair Kit | PROVE verification | Boost pressure 0.0 -> 28.5 PSI |
| **Stage 5** | Click Intelligence Tab | GAP & NOVA cards | ₹6,250 saved; TSB alert triggered |
