# TORQ Demo Dataset Summary

**SYNTHETIC DEMONSTRATION DATA — NOT PACCAR PROPRIETARY CONTENT**

---

## Overview
This document provides a high-level summary of the demonstration assets included in `torq-data/demo/` for integration into the TORQ application.

---

## Included Demonstration Artifacts

### 1. `case_001.json` (Primary Interactive Demo State Graph)
- Complete JSON representation of `CASE-001`.
- Contains 9 structured state transition steps guiding an end-to-end interactive UI flow.
- Fully compatible with frontend state machines, vector databases, and LLM reasoning prompts.

### 2. `case_001_walkthrough.md` (Hackathon Presentation Script)
- Stage-by-stage guide for hackathon presenters.
- Details explicit user inputs, expected system responses, and script talking points.
- Highlights key metrics (₹6,250 cost savings, 28.5 PSI telemetry verification, 42% fleet failure spike).

---

## Key Metrics & Demonstrable Features

| Feature | Demonstration Evidence | Consuming Component |
| :--- | :--- | :--- |
| **Reasoning Flow** | 9-step state graph from Symptom to Learn | Reasoner Engine / RAG |
| **TORQ GAP** | 12 historical cases showing sensor vs connector gap | Analytics Dashboard |
| **TORQ NOVA** | Q1-Q4 temporal spike (6% -> 42%) on `TX-900 v4.2.1` | Engineering Alert System |
| **TORQ PROVE** | Pre: 14.2 PSI, Derate 40% -> Post: 28.5 PSI, 0 Codes | Telemetry Verification Module |
| **Parts Integration** | Parts `DEMO-P-011`, `DEMO-P-012`, `DEMO-P-018` | Inventory & Costing Module |

---

## Integration Readiness
All demo files strictly adhere to the project-wide data dictionary (`DATA_DICTIONARY.md`) and pass automated referential integrity checks (`validation/validate_data.py`).
