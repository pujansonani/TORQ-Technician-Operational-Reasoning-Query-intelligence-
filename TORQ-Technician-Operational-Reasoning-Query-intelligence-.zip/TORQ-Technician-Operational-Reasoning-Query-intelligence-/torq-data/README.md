# TORQ — Data & Domain Knowledge Package

**SYNTHETIC DEMONSTRATION DATA — NOT PACCAR PROPRIETARY CONTENT**

---

## Welcome to the TORQ Data Package
This repository contains the synthetic diagnostic knowledge base, historical repair logs, parts catalog, diagnostic decision trees, and interactive demonstration cases for **TORQ (Technician Operational Reasoning Query Intelligence)** — an AI diagnostic copilot for heavy-vehicle service technicians.

This dataset is specifically engineered to power TORQ's core intelligence features:
- **TORQ GAP**: Identifying discrepancies between static OEM manuals and real shop-floor repairs (saving component replacement costs).
- **TORQ NOVA**: Detecting emerging fleet-wide component failure patterns over time before TSBs are published.
- **TORQ PROVE**: Verifying repair effectiveness using pre- and post-repair telemetry evidence.

---

## Directory Structure

```
torq-data/
├── README.md                           # Master package overview (this file)
├── DATA_DICTIONARY.md                  # Comprehensive field schema & consumption dictionary
├── DATA_PROVENANCE.md                  # Safety, licensing & non-proprietary declarations
├── validation/
│   ├── validate_data.py                # Automated integrity validation script
│   ├── validation_report.md            # Execution results of validation (PASS)
│   └── expected_relationships.md       # Graph schema & entity relationship rules
├── dtc/
│   └── dtc_kb.csv                      # Diagnostic Trouble Code knowledge base (18 codes)
├── procedures/                         # Synthetic diagnostic decision trees (7 procedures)
│   ├── boost_system.md
│   ├── intake_system.md
│   ├── sensor_electrical.md
│   ├── wiring_connector.md
│   ├── fuel_system.md
│   ├── aftertreatment.md
│   └── cooling_system.md
├── repairs/
│   └── repairs.csv                     # Historical repair records (60 synthetic cases)
├── parts/
│   └── parts.json                      # Synthetic spare parts catalog (18 parts)
└── demo/
    ├── case_001.json                   # Main end-to-end interactive demo case state graph
    ├── case_001_walkthrough.md         # Hackathon presenter script & live walkthrough
    └── demo_dataset_summary.md         # High-level summary of demo capabilities
```

---

## Quick Start for Application Teammates

### 1. Running Validation
To verify data integrity at any time:
```bash
python torq-data/validation/validate_data.py
```
Expected output: `RESULT: PASS` with zero referential integrity or math errors.

### 2. Consuming Data for Backend / RAG
- **DTC Base**: Load `torq-data/dtc/dtc_kb.csv` into vector DB or relational table for initial fault code matching.
- **Decision Trees**: Parse markdown files in `torq-data/procedures/*.md` to populate branching diagnostic logic.
- **Historical RAG**: Vectorize `torq-data/repairs/repairs.csv` for similarity search against incoming technician symptoms.

### 3. Running Live Demo (`CASE-001`)
Follow the step-by-step presentation script in `torq-data/demo/case_001_walkthrough.md` and load `torq-data/demo/case_001.json` into the frontend state engine.

---

## Safety & Licensing
All content in this dataset is synthetic and created for educational/demonstration purposes only.
- **No Proprietary Data**: Does not derive from PACCAR proprietary service manuals.
- **Public Standards**: SAE J1939 codes preserve public standard definitions.
- **Not for Maintenance**: Do not use to service real commercial vehicles.
