# DATA PROVENANCE & LEGAL DECLARATION

**SYNTHETIC DEMONSTRATION DATA — NOT PACCAR PROPRIETARY CONTENT**

---

## 1. Safety & Legal Declarations

1. **Synthetic Nature**: All data contained within the `torq-data/` repository—including DTC definitions, historical repair logs, parts catalog numbers, diagnostic trees, and demonstration case states—has been synthesized solely for demonstration, hackathon evaluation, and software integration purposes.
2. **No Proprietary Claim**: This dataset does **NOT** contain, reproduce, or derive from PACCAR Inc. proprietary service manuals, copyrighted engineering specifications, confidential repair databases, or trade secrets.
3. **Engine & Vehicle Nomenclature Disclaimer**: Vehicle model designations (`TX-800`, `TX-900`, `HD-4500`, `HD-5000`) and engine model designations (`MX-13 Synthetic`, `PX-9 Synthetic`, `HD-12 Diesel Synthetic`) are generic, synthetic identifiers created strictly for hackathon demonstration. They do not represent real-world PACCAR Inc. engine calibrations, harness schematics, or proprietary vehicle data structures.
4. **Public Standards Attribution**: Where standard diagnostic trouble codes (DTCs) or parameters are referenced (e.g., SAE J1939 Suspect Parameter Numbers [SPN] and Failure Mode Identifiers [FMI]), standard public domain definitions are cited. Their inclusion preserves public industry provenance and does not constitute real-world diagnostic advice for specific commercial vehicles.
5. **Non-Commercial / Educational Use**: This data is intended strictly for building and testing the TORQ (Technician Operational Reasoning Query Intelligence) AI copilot demonstration.

---

## 2. Provenance Categorization

To maintain explicit clarity, all entities in this dataset are tagged with metadata fields indicating source provenance:

| Category | Source Type Marker | Data Status Marker | Description |
| :--- | :--- | :--- | :--- |
| **Public Standard** | `PUBLIC_STANDARD` | `VERIFIED_PUBLIC` | Standard SAE J1939 / ISO 15031 DTCs, SPNs, and FMIs derived from publicly accessible technical specifications. |
| **Synthetic Demo** | `SYNTHETIC_DEMO` | `SYNTHETIC` | Fully synthesized diagnostic procedures, part catalog items (`DEMO-P-xxx`), and repair logs created for TORQ feature testing. |

---

## 3. Disclaimers

> [!WARNING]
> **NOT FOR VEHICLE MAINTENANCE OR SERVICING**: Do not use any procedure, part number, wiring schematic, or diagnostic recommendation from this repository to service real heavy-duty vehicles, machinery, or industrial equipment. Always consult official OEM service manuals and certified technicians for actual vehicle maintenance.

---

## 4. Synthetic Generation Methodology

- **Parts Catalog**: Created using standard pricing formulas and generic component descriptions (`DEMO-P-001` through `DEMO-P-018`).
- **DTC Knowledge Base**: Built using standard SAE J1939 fault codes and explicitly tagged synthetic demonstration codes (`DEMO-DTC-101` to `DEMO-DTC-103`).
- **Repair History**: 60 synthetic cases generated with realistic heavy-vehicle failure probabilities, intentional field-vs-manual variance patterns (TORQ GAP), emerging component failure trends (TORQ NOVA), and pre/post telemetry evidence (TORQ PROVE).
