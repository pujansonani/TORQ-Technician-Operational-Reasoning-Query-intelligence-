# TORQ — Data & Domain Knowledge Architecture Plan

## Executive Summary
This document outlines the architectural design, data schemas, domain relationships, deliberate historical patterns, and validation strategy for the **TORQ (Technician Operational Reasoning Query Intelligence)** synthetic data package.

TORQ is an AI diagnostic copilot for heavy-vehicle service technicians. As the Data & Domain Knowledge layer, this dataset provides structured diagnostic knowledge, standard DTC definitions, synthetic procedure branching trees, parts catalogs, and historical repair records tailored to demonstrate TORQ's core intelligence capabilities: **TORQ GAP**, **TORQ NOVA**, and **TORQ PROVE**.

---

## 1. Dataset Architecture & Directory Layout

The dataset is organized under `torq-data/` with the following clean layout:

```
torq-data/
├── README.md                           # Master entrypoint & dataset overview
├── DATA_DICTIONARY.md                  # Comprehensive schema documentation
├── DATA_PROVENANCE.md                  # Safety, licensing & provenance declarations
├── validation/
│   ├── validate_data.py                # Automated integrity validation script
│   ├── validation_report.md            # Execution results of validation
│   └── expected_relationships.md       # Graph schema & entity relationship rules
├── dtc/
│   └── dtc_kb.csv                      # Diagnostic Trouble Code knowledge base (18 codes)
├── procedures/                         # Synthetic diagnostic decision trees (7 procedures)
│   ├── boost_system.md
│   ├── intake_system.md
│   ├── sensor_electrical.md
│   ├── wiring_connector.md
│   ├── fuel_system.md
│   ├── aftertreatment.md
│   └── cooling_system.md
├── repairs/
│   └── repairs.csv                     # Historical repair records (60 cases)
├── parts/
│   └── parts.json                      # Synthetic spare parts catalog (18 parts)
└── demo/
    ├── case_001.json                   # Main end-to-end interactive demo case state graph
    ├── case_001_walkthrough.md         # Hackathon presenter script & live walkthrough
    └── demo_dataset_summary.md         # High-level summary of demo capabilities
```

---

## 2. Core Operational & Diagnostic Workflows

The TORQ dataset is designed to move beyond traditional naive chatbot lookups (`Symptom -> LLM Guess -> Replace Part`). Instead, it models the rigorous heavy-vehicle diagnostic reasoning flow:

```
SYMPTOM + DTC
      ↓
UNDERSTAND (Telemetry & Baseline Analysis)
      ↓
RETRIEVE EVIDENCE (Match DTC KB + Diagnostic Decision Trees)
      ↓
RANK POSSIBLE CAUSES (Probabilistic Prior based on Field History)
      ↓
RECOMMEND NEXT DIAGNOSTIC TEST (Optimal cost/time diagnostic step)
      ↓
TECHNICIAN ENTERS RESULT (Pass / Fail / Measured Value)
      ↓
UPDATE DIAGNOSTIC STATE (Bayesian state transition & cause re-ranking)
      ↓
CONFIRM ROOT CAUSE (Pinpoint component / connector fault)
      ↓
REPAIR (Execute verified repair action with parts)
      ↓
VERIFY REPAIR (Post-repair telemetry check: PROVE)
      ↓
LEARN FROM CASE (Update historical feedback loop: GAP & NOVA)
```

---

## 3. Detailed Entity Relationships & Schemas

### 3.1 DTC Knowledge Base (`dtc/dtc_kb.csv`)
- **Primary Key**: `code` (e.g., `P0237`, `DEMO-DTC-101`)
- **Fields**:
  - `code`: Standard or synthetic diagnostic trouble code string.
  - `spn`: Suspect Parameter Number (J1939 standard or synthetic).
  - `fmi`: Failure Mode Identifier (J1939 standard or synthetic).
  - `description`: Formal diagnostic description.
  - `subsystem`: Target vehicle subsystem.
  - `severity`: Severity level (`CRITICAL`, `HIGH`, `MODERATE`, `LOW`).
  - `symptom_keywords`: Pipe-separated list of observed symptoms.
  - `possible_causes`: Pipe-separated candidate failure modes.
  - `diagnostic_tests`: Pipe-separated list of standard tests.
  - `expected_results`: Expected nominal values or states.
  - `failure_results`: Non-nominal outcomes triggering failure paths.
  - `repair_actions`: Recommended resolution steps.
  - `source_type`: `PUBLIC_STANDARD` vs `SYNTHETIC_DEMO`.
  - `source_reference`: SAE J1939 / ISO standard citation or synthetic tag.
  - `data_status`: `VERIFIED_PUBLIC` vs `SYNTHETIC`.

### 3.2 Parts Catalog (`parts/parts.json`)
- **Primary Key**: `part_number` (e.g., `DEMO-P-001`)
- **Fields**:
  - `part_number`: Synthetic part ID prefix (`DEMO-P-xxx`).
  - `description`: Part nomenclature.
  - `price_inr`: Cost in INR.
  - `compatible_models`: Array of compatible vehicle models.
  - `subsystem`: Subsystem assignment.
  - `data_status`: Always `SYNTHETIC`.

### 3.3 Diagnostic Procedures (`procedures/*.md`)
Structured markdown decision trees containing metadata headers, preconditions, symptoms, candidate causes, step-by-step diagnostic nodes with explicit `PASS` and `FAIL` branching, repair guidance, post-repair verification criteria, and safety notes.

### 3.4 Historical Repair Dataset (`repairs/repairs.csv`)
- **Primary Key**: `case_id` (`CASE-HIST-001` through `CASE-HIST-060`)
- **Fields**:
  - `case_id`: Unique identifier.
  - `vehicle_model`, `engine`, `mileage_km`, `software_version`: Vehicle metadata.
  - `symptom`, `dtc_code`: Initial entry state.
  - `documented_path`: Standard manual path (e.g., `DTC -> Sensor Test -> Replace Sensor`).
  - `actual_path`: Real field diagnostic steps taken (e.g., `DTC -> Sensor Test PASS -> Connector Inspection -> Clean/Repair Wiring`).
  - `tests_performed`: Pipe-separated tests executed.
  - `root_cause`: Final confirmed root cause.
  - `repair_action`: Specific action executed.
  - `parts_used`: Pipe-separated part numbers (must match `parts.json`).
  - `labor_hours`, `parts_cost_inr`, `labor_cost_inr`, `total_cost_inr`: Cost metrics (`total = parts + labor`).
  - `resolved`: `true` / `false`.
  - `verification_evidence`: Structured JSON/string of BEFORE and AFTER parameter states.
  - `created_at`: ISO timestamp for temporal sequence analysis.
  - `data_status`: Always `SYNTHETIC_DEMO`.

---

## 4. Intended TORQ Core Features Supported

### 4.1 TORQ GAP (Field vs. Manual Variance)
- **Concept**: Standard OEM service manuals often prescribe replacing expensive sensors immediately upon DTC trigger. Field experience reveals that connector corrosion or pin fretting is frequently the real root cause.
- **Dataset Support**: 12 specific repair cases in `repairs.csv` exhibit `documented_path` pointing to sensor replacement, whereas `actual_path` records pin/connector repair.
- **Value**: Highlights diagnostic efficiency gains and parts cost savings.

### 4.2 TORQ NOVA (Emerging Pattern Detection)
- **Concept**: Identifying systemic emerging failures across specific vehicle batches, software versions, or seasonal timeframes before official TSBs are published.
- **Dataset Support**: Historical case timestamps across 2025–2026 demonstrate a sharp uptick in connector corrosion cases on `TX-900` models running software `v4.2.1` in high-humidity/salt environments during Q3–Q4.
- **Output Phrasing**: `"Emerging pattern detected — engineering review recommended."`

### 4.3 TORQ PROVE (Quantifiable Repair Verification)
- **Concept**: Validating repair effectiveness using pre- and post-repair telemetry evidence rather than just clearing DTCs.
- **Dataset Support**: Every resolved case in `repairs.csv` includes structured `verification_evidence` showing baseline parameters vs post-repair values (e.g. Boost pressure: 14.2 PSI pre -> 28.5 PSI post).

---

## 5. Main Demonstration Case (`CASE-001`)

`CASE-001` serves as the primary showcase for hackathon live demos. It details the complete journey of a heavy truck (`TX-900`) experiencing `"Loss of power when climbing an incline"` with active DTC `P0237` (Boost Pressure Sensor Circuit Low).

The state transitions in `case_001.json` guide the technician through:
1. Initial symptom & active code registration.
2. Initial cause probability ranking (Charge air leak vs Sensor failure vs Wiring/Connector fault).
3. First recommended test: Boost sensor Vref voltage & harness inspection.
4. Technician finding: Sensor Vref is nominal (5.0V), but connector pin C042 shows green copper corrosion and loose retention.
5. Dynamic re-ranking: Connector fault becomes 98% root cause.
6. Execution of connector pigtail repair (`DEMO-P-011`).
7. Telemetry verification (PROVE): Boost pressure restored to 28.5 PSI.
8. Pattern matching against 12 historical cases (GAP) and surfacing the model-wide trend (NOVA).

---

## 6. Data Integrity & Automated Validation Strategy

To ensure zero integration friction for application developers, the automated validation script (`validation/validate_data.py`) enforces strict consistency checks:

1. **Referential Integrity**:
   - Every `dtc_code` in `repairs.csv` exists in `dtc_kb.csv`.
   - Every `parts_used` ID in `repairs.csv` exists in `parts.json`.
   - Referenced procedures exist in `procedures/`.
2. **Schema & Field Formatting**:
   - Validates CSV headers and JSON schemas.
   - Checks non-null requirements for mandatory fields.
   - Validates JSON formatting in `parts.json` and `case_001.json`.
3. **Mathematical Correctness**:
   - `total_cost_inr == parts_cost_inr + labor_cost_inr` for all 60 cases.
4. **Data Provenance & Safety**:
   - Verifies all synthetic files carry explicit non-proprietary markers.
5. **Pattern Integrity**:
   - Verifies the presence of at least 8 TORQ GAP cases.
   - Verifies NOVA emerging temporal patterns.
   - Verifies PROVE evidence formatting.

---

## 7. Next Execution Steps

1. Create directory structure `torq-data/`.
2. Generate `DATA_PROVENANCE.md` and safety headers.
3. Generate `dtc/dtc_kb.csv` (18 codes).
4. Generate `parts/parts.json` (18 synthetic parts).
5. Generate 7 markdown procedure files in `procedures/`.
6. Generate `repairs/repairs.csv` (60 synthetic cases).
7. Generate `demo/case_001.json`, `case_001_walkthrough.md`, and `demo_dataset_summary.md`.
8. Create `validation/expected_relationships.md` and `validation/validate_data.py`.
9. Execute `validate_data.py` to confirm 100% PASS status.
10. Generate `DATA_DICTIONARY.md` and `README.md`.
