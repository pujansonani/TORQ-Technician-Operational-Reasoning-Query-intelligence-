"""Embeddings package."""
