# TORQ — Fleet Intelligence Analytics & Data Specification

**SYNTHETIC DEMONSTRATION DATA — NOT PACCAR PROPRIETARY CONTENT**

---

## Executive Summary
This document defines the formal data analytics specification for the **Fleet Intelligence** module within TORQ (Technician Operational Reasoning Query Intelligence).

This specification outlines the mathematical formulas, input CSV field dependencies, edge-case algorithms, API JSON response contracts, and exact calculated benchmark outputs for **CASE-001** (`DTC P0237` on vehicle model `TX-900`) computed directly from the 60 synthetic records in `torq-data/repairs/repairs.csv`.

---

## 1. System Input Metadata & Filter Context

The Fleet Intelligence engine processes historical repair logs from `repairs/repairs.csv`.

### Primary Demo Query Context (`CASE-001`)
- **Target DTC Code**: `P0237` (Turbocharger Boost Pressure Sensor A Circuit Low)
- **Target Vehicle Model**: `TX-900`
- **Engine**: `MX-13 Synthetic`
- **Software Version**: `v4.2.1`
- **Symptom**: `"Truck loses power when climbing an incline under heavy load"`

---

## 2. Core Analytics Specifications

### 2.1 Metric 1: Similar Case Count

#### Description
Calculates the total number of historical repair cases matching the active case's filtering criteria (DTC code and/or vehicle model, symptom keywords, and software version).

#### Mathematical Formula
$$\text{SimilarCaseCount}(C) = \sum_{r \in R} \mathbb{I}\Big(r.\text{dtc\_code} = C.\text{dtc\_code} \;\land\; r.\text{vehicle\_model} = C.\text{vehicle\_model}\Big)$$

Where:
- $R$ is the set of all repair records in `repairs.csv`.
- $C$ is the active diagnostic case query context.
- $\mathbb{I}(\cdot)$ is the indicator function returning $1$ if true, $0$ if false.

#### Input Fields Consumed
- `repairs.csv`: `dtc_code`, `vehicle_model`, `symptom`, `software_version`

#### Calculated Output for `CASE-001`
- **Matching Filter**: `dtc_code == 'P0237'` AND `vehicle_model == 'TX-900'`
- **Calculated Count**: **28 cases** (out of 60 total dataset records)

#### API Response JSON Shape
```json
{
  "metric": "similar_case_count",
  "query_filter": {
    "dtc_code": "P0237",
    "vehicle_model": "TX-900"
  },
  "data": {
    "count": 28,
    "total_historical_cases_evaluated": 60,
    "match_confidence": 1.00
  }
}
```

#### Edge Cases & Handling
- **Zero Matches Found**: If $\text{SimilarCaseCount} = 0$, fall back to broadening filter: match on `dtc_code` alone across all vehicle models.
- **Null / Empty Fields**: Skip records missing required `dtc_code` or `vehicle_model`.

---

### 2.2 Metric 2: Resolution Rate by Root Cause

#### Description
Measures the percentage of repair attempts that successfully resolved the vehicle issue (`resolved == true`) grouped by specific root cause category.

#### Mathematical Formula
$$\text{ResolutionRate}(k) = \frac{\sum_{r \in R_k} \mathbb{I}\big(r.\text{resolved} = \text{true}\big)}{|R_k|} \times 100\%$$

Where:
- $R_k = \{r \in R \mid \text{Categorize}(r.\text{root\_cause}) = k \;\land\; \text{FilterMatch}(r)\}$
- $|R_k|$ is the total number of repair cases in category $k$.

#### Input Fields Consumed
- `repairs.csv`: `root_cause`, `resolved`, `dtc_code`, `vehicle_model`

#### Calculated Output for `CASE-001`
- **Category**: `Wiring / Connector Pin Corrosion`
  - Total Cases ($|R_k|$): 28
  - Resolved Cases: 28
  - **Resolution Rate**: **100.0%**

#### API Response JSON Shape
```json
{
  "metric": "resolution_rate_by_root_cause",
  "data": {
    "categories": [
      {
        "root_cause_category": "Wiring / Connector Pin Corrosion",
        "total_cases": 28,
        "resolved_cases": 28,
        "unresolved_cases": 0,
        "resolution_rate_pct": 100.0
      }
    ]
  }
}
```

#### Edge Cases & Handling
- **Zero Category Count ($|R_k| = 0$)**: Return `null` or `0.0%` with flag `"insufficient_data"`.
- **String Case Sensitivity**: Normalize `resolved` string comparison (`'true'`, `'TRUE'`, `'True'` $\rightarrow$ boolean `true`).

---

### 2.3 Metric 3: Average Repair Cost

#### Description
Calculates the mean total repair cost (in INR), broken down by mean parts cost and mean labor cost across matching historical cases.

#### Mathematical Formula
$$\bar{C}_{\text{total}} = \frac{1}{|M|} \sum_{r \in M} r.\text{total\_cost\_inr}$$

$$\bar{C}_{\text{parts}} = \frac{1}{|M|} \sum_{r \in M} r.\text{parts\_cost\_inr}, \quad \bar{C}_{\text{labor}} = \frac{1}{|M|} \sum_{r \in M} r.\text{labor\_cost\_inr}$$

Where $M$ is the set of matching cases ($|M| = 28$ for `CASE-001`).

#### Input Fields Consumed
- `repairs.csv`: `parts_cost_inr`, `labor_cost_inr`, `total_cost_inr`, `dtc_code`, `vehicle_model`

#### Calculated Output for `CASE-001`
- **Sum Parts Cost**: ₹147,800.00 INR
- **Sum Labor Cost**: ₹87,000.00 INR
- **Sum Total Cost**: ₹234,800.00 INR
- **Average Parts Cost ($\bar{C}_{\text{parts}}$)**: **₹5,278.57 INR**
- **Average Labor Cost ($\bar{C}_{\text{labor}}$)**: **₹3,107.14 INR**
- **Average Total Cost ($\bar{C}_{\text{total}}$)**: **₹8,385.71 INR**
- **Comparison to Manual Replacement**: Saves **₹6,250.00 INR** per vehicle vs replacing sensor (`DEMO-P-001` ₹12,500 + labor).

#### API Response JSON Shape
```json
{
  "metric": "average_repair_cost",
  "currency": "INR",
  "data": {
    "sample_size": 28,
    "avg_total_cost_inr": 8385.71,
    "avg_parts_cost_inr": 5278.57,
    "avg_labor_cost_inr": 3107.14,
    "min_total_cost_inr": 5000.00,
    "max_total_cost_inr": 10000.00,
    "oem_manual_estimated_cost_inr": 14625.00,
    "avg_cost_savings_inr": 6239.29
  }
}
```

#### Edge Cases & Handling
- **Negative or Non-Numeric Values**: Filter out malformed records where `total_cost_inr < 0`.
- **Cost Mismatch**: Validate $r.\text{total\_cost\_inr} = r.\text{parts\_cost\_inr} + r.\text{labor\_cost\_inr}$ before aggregation.

---

### 2.4 Metric 4: Average Labor Hours

#### Description
Calculates the average billable technician labor hours spent to complete the repair for matching cases.

#### Mathematical Formula
$$\bar{L} = \frac{1}{|M|} \sum_{r \in M} r.\text{labor\_hours}$$

#### Input Fields Consumed
- `repairs.csv`: `labor_hours`, `dtc_code`, `vehicle_model`

#### Calculated Output for `CASE-001`
- **Sum Labor Hours**: 58.0 hours across 28 cases
- **Average Labor Hours ($\bar{L}$)**: **2.07 hours** (124 minutes)
- **Range**: Minimum 1.5 hrs, Maximum 2.5 hrs

#### API Response JSON Shape
```json
{
  "metric": "average_labor_hours",
  "data": {
    "sample_size": 28,
    "avg_labor_hours": 2.07,
    "min_labor_hours": 1.50,
    "max_labor_hours": 2.50,
    "estimated_duration_display": "2 hrs 4 mins"
  }
}
```

#### Edge Cases & Handling
- **Zero / Missing Hours**: Exclude records where `labor_hours <= 0` or missing.

---

### 2.5 Metric 5: Root-Cause Distribution

#### Description
Calculates the relative percentage and absolute frequency distribution of confirmed root causes across matching historical cases.

#### Mathematical Formula
$$\text{DistributionPct}(k) = \frac{|\{r \in M \mid \text{Categorize}(r.\text{root\_cause}) = k\}|}{|M|} \times 100\%$$

#### Input Fields Consumed
- `repairs.csv`: `root_cause`, `dtc_code`, `vehicle_model`

#### Calculated Output for `CASE-001`
- Filter: `dtc_code == 'P0237'` AND `vehicle_model == 'TX-900'`
- **Categories**:
  1. `Wiring / Connector Pin Corrosion`: **28 cases (100.0%)**
  2. `Boost Sensor Internal Component Failure`: **0 cases (0.0%)**
  3. `Charge Air Cooler Hose Leakage`: **0 cases (0.0%)**
  4. `VGT Actuator Sticking`: **0 cases (0.0%)**

#### API Response JSON Shape
```json
{
  "metric": "root_cause_distribution",
  "data": {
    "total_evaluated": 28,
    "distribution": [
      {
        "category": "Wiring / Connector Pin Corrosion",
        "count": 28,
        "percentage": 100.0,
        "is_primary_cause": true
      },
      {
        "category": "Sensor Internal Component Failure",
        "count": 0,
        "percentage": 0.0,
        "is_primary_cause": false
      }
    ]
  }
}
```

#### Edge Cases & Handling
- **High Cardinality Text**: Group fine-grained text descriptions (e.g., "Connector C042 Pin B Oxidation", "Corrosion Scale on C042") into standardized high-level categories using semantic string rules.

---

### 2.6 Metric 6: Recent Trend

#### Description
Tracks the monthly or quarterly case frequency volume over time for the target fault pattern across historical repair timestamps (`created_at`).

#### Mathematical Formula
$$\text{QuarterlyCount}(q) = \sum_{r \in M} \mathbb{I}\Big(\text{Quarter}(r.\text{created\_at}) = q\Big)$$

#### Input Fields Consumed
- `repairs.csv`: `created_at`, `dtc_code`, `vehicle_model`, `root_cause`

#### Calculated Output for `CASE-001` (`P0237` + `TX-900`)
- **2025-Q1**: 2 cases
- **2025-Q2**: 2 cases
- **2025-Q3**: 4 cases
- **2025-Q4**: 4 cases
- **2026-Q1**: 4 cases
- **2026-Q2**: 4 cases
- **2026-Q3**: 8 cases
- **Growth Trend**: Volume increased from 2 cases/quarter in H1 2025 to 8 cases/quarter in Q3 2026 (+300% quarterly volume growth).

#### API Response JSON Shape
```json
{
  "metric": "recent_trend",
  "time_granularity": "quarterly",
  "data": {
    "time_series": [
      { "period": "2025-Q1", "case_count": 2 },
      { "period": "2025-Q2", "case_count": 2 },
      { "period": "2025-Q3", "case_count": 4 },
      { "period": "2025-Q4", "case_count": 4 },
      { "period": "2026-Q1", "case_count": 4 },
      { "period": "2026-Q2", "case_count": 4 },
      { "period": "2026-Q3", "case_count": 8 }
    ],
    "overall_direction": "UPWARD_SURGE",
    "growth_rate_pct": 300.0
  }
}
```

#### Edge Cases & Handling
- **Missing Timestamps**: Parse ISO format `YYYY-MM-DDTHH:MM:SSZ`. Default missing dates to creation epoch.

---

### 2.7 Metric 7: Emerging Failure Pattern (TORQ NOVA)

#### Description
Calculates whether a specific component or connector failure rate on a target vehicle model/software version displays a statistically significant upward surge relative to total fleet repair volume over consecutive quarters.

#### Mathematical Formula
$$\text{NOVA\_Ratio}(q) = \frac{\text{TargetPatternCases}(q)}{\text{TotalFleetCases}(q)}$$

$$\Delta \text{NOVA} = \text{NOVA\_Ratio}(q_{\text{latest}}) - \text{NOVA\_Ratio}(q_{\text{earliest}})$$

$$\text{TriggerAlert} = \text{TRUE} \quad \text{IF} \quad \Delta \text{NOVA} \ge +0.20 \;\lor\; \text{NOVA\_Ratio}(q_{\text{latest}}) \ge 0.40$$

#### Input Fields Consumed
- `repairs.csv`: `created_at`, `vehicle_model`, `software_version`, `dtc_code`, `root_cause`

#### Calculated Output for `CASE-001`
- **2025-Q1 Fleet Ratio**: $\frac{2 \text{ cases}}{7 \text{ total fleet cases}} = 28.6\%$
- **2025-Q4 Fleet Ratio**: $\frac{4 \text{ cases}}{7 \text{ total fleet cases}} = 57.1\%$
- **2026-Q3 Fleet Ratio**: $\frac{8 \text{ cases}}{15 \text{ total fleet cases}} = 53.3\%$
- **$\Delta \text{NOVA}$ Change**: $+24.7\%$ increase from 2025-Q1 to 2026-Q3.
- **Alert Condition Met**: $\text{NOVA\_Ratio}(2026\text{-Q3}) = 53.3\% > 40.0\%$ threshold.
- **Calculated Output Phrase**: `"Emerging pattern detected — engineering review recommended."`

#### API Response JSON Shape
```json
{
  "metric": "emerging_failure_pattern_nova",
  "data": {
    "is_emerging_pattern": true,
    "target_model": "TX-900",
    "software_version": "v4.2.1",
    "affected_subsystem": "wiring_connector",
    "baseline_ratio_q1_2025": 0.286,
    "current_ratio_q3_2026": 0.533,
    "ratio_increase_delta": 0.247,
    "output_phrase": "Emerging pattern detected — engineering review recommended.",
    "recommendation": "Recommend issuing Field Technical Service Bulletin (TSB) for Weatherpack connector seal housing C042."
  }
}
```

#### Edge Cases & Handling
- **Small Sample Warning**: If total fleet cases in quarter $< 5$, suppress alert to prevent false positives from noise.
- **Non-Hardcoded Compliance**: Always calculate ratio directly from timestamp aggregations.

---

### 2.8 Metric 8: Number of Cases Where Actual Path Differs From Documented Path (TORQ GAP)

#### Description
Counts historical repair records where the actual field diagnostic steps (`actual_path`) differed from the static OEM service manual path (`documented_path`), proving shop-floor diagnostic variance.

#### Mathematical Formula
$$\text{GAP\_CaseCount}(M) = \sum_{r \in M} \mathbb{I}\Big(\text{Normalize}(r.\text{documented\_path}) \neq \text{Normalize}(r.\text{actual\_path})\Big)$$

$$\text{GAP\_Ratio}(M) = \frac{\text{GAP\_CaseCount}(M)}{|M|} \times 100\%$$

#### Input Fields Consumed
- `repairs.csv`: `documented_path`, `actual_path`, `dtc_code`, `vehicle_model`

#### Calculated Output for `CASE-001`
- **Filter**: `dtc_code == 'P0237'` AND `vehicle_model == 'TX-900'`
- **Matching Case Count ($|M|$)**: 28 cases
- **Documented Path**: `DTC P0237 -> Voltage Test -> Replace Boost Sensor`
- **Actual Path**: `DTC P0237 -> Sensor Vref Test PASS (5.0V) -> Connector C042 Pin Inspection -> Pin Corrosion Found -> Crimp Repair Pigtail -> Retest OK`
- **Differing Cases Count ($\text{GAP\_CaseCount}$)**: **28 cases**
- **GAP Ratio**: **100.0%** (28 out of 28 cases)
- **Dataset Wide Total GAP Cases**: **60 cases** out of 60 records (100.0%)

#### API Response JSON Shape
```json
{
  "metric": "torq_gap_differing_paths_count",
  "data": {
    "total_evaluated_cases": 28,
    "differing_paths_count": 28,
    "matching_paths_count": 0,
    "gap_percentage": 100.0,
    "primary_documented_path": "DTC P0237 -> Voltage Test -> Replace Boost Sensor",
    "primary_actual_path": "DTC P0237 -> Sensor Vref Test PASS -> Connector C042 Pin Inspection -> Crimp Repair Pigtail",
    "field_insight": "85% of field cases resolve DTC P0237 via Weatherpack connector C042 pigtail repair rather than sensor replacement."
  }
}
```

#### Edge Cases & Handling
- **Whitespace / Punctuation Sensitivity**: Strip leading/trailing spaces and convert strings to lower case before string inequality comparison.

---

## 3. Master Combined API Response Object (`CASE-001`)

Below is the complete, single consolidated JSON payload returned by the Fleet Intelligence API endpoint `GET /api/v1/fleet-intelligence?dtc=P0237&model=TX-900`:

```json
{
  "status": "success",
  "timestamp": "2026-09-26T12:16:34Z",
  "query_context": {
    "dtc_code": "P0237",
    "vehicle_model": "TX-900",
    "engine": "MX-13 Synthetic",
    "software_version": "v4.2.1"
  },
  "fleet_analytics": {
    "similar_case_count": 28,
    "total_fleet_records_evaluated": 60,
    "resolution_rate": {
      "overall_pct": 100.0,
      "by_cause": [
        {
          "category": "Wiring / Connector Pin Corrosion",
          "total_cases": 28,
          "resolved_cases": 28,
          "resolution_rate_pct": 100.0
        }
      ]
    },
    "cost_metrics_inr": {
      "currency": "INR",
      "avg_total_cost": 8385.71,
      "avg_parts_cost": 5278.57,
      "avg_labor_cost": 3107.14,
      "estimated_manual_cost": 14625.00,
      "avg_savings_per_repair": 6239.29
    },
    "labor_metrics": {
      "avg_labor_hours": 2.07,
      "min_labor_hours": 1.5,
      "max_labor_hours": 2.5
    },
    "root_cause_distribution": [
      {
        "category": "Wiring / Connector Pin Corrosion",
        "count": 28,
        "percentage": 100.0
      }
    ],
    "recent_trend_quarterly": [
      { "period": "2025-Q1", "case_count": 2 },
      { "period": "2025-Q2", "case_count": 2 },
      { "period": "2025-Q3", "case_count": 4 },
      { "period": "2025-Q4", "case_count": 4 },
      { "period": "2026-Q1", "case_count": 4 },
      { "period": "2026-Q2", "case_count": 4 },
      { "period": "2026-Q3", "case_count": 8 }
    ],
    "torq_nova": {
      "is_emerging_pattern": true,
      "output_phrase": "Emerging pattern detected — engineering review recommended.",
      "q1_2025_ratio": 0.286,
      "q3_2026_ratio": 0.533
    },
    "torq_gap": {
      "differing_paths_count": 28,
      "total_cases": 28,
      "gap_percentage": 100.0
    }
  }
}
```
